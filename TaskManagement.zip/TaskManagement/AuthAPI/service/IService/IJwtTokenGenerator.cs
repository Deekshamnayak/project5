﻿using AuthAPI.Models;

namespace AuthAPI.service.IService
{
    public interface IJwtTokenGenerator
    {
        string GenerateToken(ApplicationUser applicationUser);
    }
}
