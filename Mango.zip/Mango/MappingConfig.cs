﻿using AutoMapper;
using CouponAPI.Models;
using CouponAPI.Models.Dto;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.Blazor;
namespace CouponAPI
{
    public class MappingConfig:Profile
    {
       /* public static MapperConfiguration RegisteredMaps()
        {
            var mappingConfig = new MapperConfiguration(config =>
            {
                config.CreateMap<CouponDto, Coupon>();
                config.CreateMap<Coupon, CouponDto>();
            });
            return mappingConfig;
        }*/

        public MappingConfig() 
        {
            CreateMap<CouponDto, Coupon>();
            CreateMap<Coupon, CouponDto>();

        }
    }
}
